"""
Precision Agriculture Recommendation Engine.
Translates Digital Twin multi-modal states and SFQL crop stress classifications
into concrete, actionable farm prescriptions:
1. Variable Rate Irrigation (VRI)
2. Variable Rate Fertilization (VRF: N, P, K)
3. Biosecurity / Pathogen Scouting Alerts
4. Next-mission UAV waypoint flight paths
"""

import numpy as np
from typing import Dict, List, Tuple, Any, Optional
from data.data_generator import CropStressType


class AgronomicPrescription:
    """Encapsulates prescriptive management recommendations for the farm."""
    def __init__(self, irrigation_schedule: Dict[int, Dict[str, Any]],
                 fertilizer_prescriptions: Dict[int, Dict[str, float]],
                 pathology_alerts: List[Dict[str, Any]],
                 next_uav_waypoints: List[int],
                 resource_saving_rate_pct: float):
        self.irrigation_schedule = irrigation_schedule
        self.fertilizer_prescriptions = fertilizer_prescriptions
        self.pathology_alerts = pathology_alerts
        self.next_uav_waypoints = next_uav_waypoints
        self.resource_saving_rate_pct = resource_saving_rate_pct


class PrecisionAgricultureRecommender:
    """
    Automated decision support system driven by the real-time Digital Twin.
    """
    def __init__(self, config: dict, zone_coords: np.ndarray):
        self.config = config
        self.zone_coords = zone_coords
        self.num_zones = len(zone_coords)
        self.zone_area_m2 = config['farm']['zone_area_m2']
        self.crop_cfg = config['crop_parameters']
        self.dec_cfg = config['decision_layer']

    def generate_recommendations(self, digital_twin_state: np.ndarray,
                                 stress_class_predictions: np.ndarray,
                                 adaptive_uav_visited_zones: List[int]) -> AgronomicPrescription:
        """
        Processes Digital Twin states and stress predictions to generate site-specific actions.
        """
        irrigation_schedule = {}
        fertilizer_prescriptions = {}
        pathology_alerts = []

        total_baseline_water_liters = 0.0
        total_prescribed_water_liters = 0.0

        for z in range(self.num_zones):
            soil_moist = digital_twin_state[z, 0]
            soil_temp = digital_twin_state[z, 1]
            n_val = digital_twin_state[z, 5]
            p_val = digital_twin_state[z, 6]
            k_val = digital_twin_state[z, 7]
            pred_stress = stress_class_predictions[z]

            # 1. Variable Rate Irrigation (VRI)
            # Baseline blanket irrigation: applies uniform 1000 Liters to all parcels
            baseline_water_per_parcel = 1200.0
            total_baseline_water_liters += baseline_water_per_parcel

            opt_moist = self.crop_cfg['optimal_soil_moisture_pct']
            deficit = max(0.0, opt_moist - soil_moist)

            if deficit > 2.0 or pred_stress == CropStressType.WATER_STRESS:
                # Liters needed = Deficit (%) * area * factor / efficiency
                prescribed_liters = (deficit * self.zone_area_m2 * 0.15) / self.dec_cfg['irrigation_efficiency']
                urgency = "HIGH" if deficit > 8.0 else "MEDIUM"
                irrigation_schedule[z] = {
                    'current_moisture_pct': float(soil_moist),
                    'deficit_pct': float(deficit),
                    'recommended_water_liters': float(np.round(prescribed_liters, 1)),
                    'urgency': urgency,
                    'zone_center': self.zone_coords[z].tolist()
                }
                total_prescribed_water_liters += prescribed_liters

            # 2. Variable Rate Fertilization (VRF: N-P-K)
            n_opt = self.crop_cfg['optimal_nitrogen_mg_kg']
            p_opt = self.crop_cfg['optimal_phosphorus_mg_kg']
            k_opt = self.crop_cfg['optimal_potassium_mg_kg']

            n_def = max(0.0, n_opt - n_val)
            p_def = max(0.0, p_opt - p_val)
            k_def = max(0.0, k_opt - k_val)

            if n_def > 5.0 or p_def > 3.0 or k_def > 15.0 or pred_stress == CropStressType.NUTRIENT_DEFICIENCY:
                fertilizer_prescriptions[z] = {
                    'nitrogen_supplement_kg_ha': float(np.round(n_def * self.dec_cfg['nitrogen_supplement_kg_per_mg_kg'], 2)),
                    'phosphorus_supplement_kg_ha': float(np.round(p_def * self.dec_cfg['phosphorus_supplement_kg_per_mg_kg'], 2)),
                    'potassium_supplement_kg_ha': float(np.round(k_def * self.dec_cfg['potassium_supplement_kg_per_mg_kg'], 2)),
                    'zone_center': self.zone_coords[z].tolist()
                }

            # 3. Pathogen Disease Scouting Alert
            if pred_stress == CropStressType.PATHOGEN_DISEASE:
                pathology_alerts.append({
                    'zone_id': z,
                    'coordinates_m': self.zone_coords[z].tolist(),
                    'diagnosis': 'Potential Foliar / Fungal Pathogen Outbreak',
                    'action': 'Immediate ground visual scout & targeted fungicide barrier spraying',
                    'severity': 'CRITICAL'
                })

        # Resource-saving rate: water saved compared to blanket irrigation
        water_saved_liters = max(0.0, total_baseline_water_liters - total_prescribed_water_liters)
        water_saving_pct = (water_saved_liters / max(1.0, total_baseline_water_liters)) * 100.0

        # Next UAV mission: focus on high-deficit or disease-adjacent parcels
        next_waypoints = [z for z in range(self.num_zones) if (z in irrigation_schedule or any(a['zone_id'] == z for a in pathology_alerts)) and z not in adaptive_uav_visited_zones[:5]]
        if not next_waypoints:
            next_waypoints = list(np.random.choice(self.num_zones, size=8, replace=False))

        return AgronomicPrescription(
            irrigation_schedule=irrigation_schedule,
            fertilizer_prescriptions=fertilizer_prescriptions,
            pathology_alerts=pathology_alerts,
            next_uav_waypoints=next_waypoints[:12],
            resource_saving_rate_pct=float(water_saving_pct)
        )
