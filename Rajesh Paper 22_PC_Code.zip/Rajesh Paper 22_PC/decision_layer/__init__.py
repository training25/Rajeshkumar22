"""
Adaptive Decision Layer for Precision Agriculture.
Generates site-specific agronomic recommendations:
- Variable Rate Irrigation (VRI)
- Variable Rate Fertilization (VRF)
- Targeted Crop Pathology Inspections
- Next UAV Mission Trajectory Planning
"""

from .recommendation_engine import PrecisionAgricultureRecommender, AgronomicPrescription

__all__ = ['PrecisionAgricultureRecommender', 'AgronomicPrescription']
