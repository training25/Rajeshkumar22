"""
Visualization and Scientific Plotting Suite for Precision Agriculture Digital Twin.
Generates publication-ready figures for metric comparisons, spatial heatmaps,
UAV scanning trajectories, BHOA convergence, and DTSE synchronization curves.
"""

from .plot_results import AgricultureVisualizer

__all__ = ['AgricultureVisualizer']
