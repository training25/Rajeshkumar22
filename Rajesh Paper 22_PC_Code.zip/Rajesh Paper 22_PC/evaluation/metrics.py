"""
Performance Metrics Calculator for Precision Agriculture Digital Twin.
Implements the 13 required metrics:
1. Accuracy (%)
2. Precision (%)
3. Recall (%)
4. F1-score (%)
5. Prediction MAE
6. Prediction RMSE
7. Digital Twin synchronization error (DTSE)
8. Spatial coverage (%)
9. UAV flight time (minutes)
10. Energy consumption (kJ)
11. Communication overhead (KB)
12. Anomaly-detection latency (ms)
13. Resource-saving rate (%)
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any, Optional

try:
    from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


class PrecisionAgricultureMetrics:
    """
    Computes and aggregates all 13 research metrics across simulation runs.
    """
    METRIC_NAMES = [
        "accuracy",
        "precision",
        "recall",
        "f1_score",
        "prediction_mae",
        "prediction_rmse",
        "digital_twin_sync_error",
        "spatial_coverage",
        "uav_flight_time",
        "energy_consumption",
        "communication_overhead",
        "anomaly_detection_latency",
        "resource_saving_rate"
    ]

    def __init__(self, scheme_name: str):
        self.scheme_name = scheme_name
        self.episode_records: List[Dict[str, float]] = []

    @staticmethod
    def compute_classification_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Tuple[float, float, float, float]:
        """Calculates Accuracy, Macro-Precision, Macro-Recall, and Macro-F1 score."""
        acc = float(np.mean(y_true == y_pred) * 100.0)

        if SKLEARN_AVAILABLE:
            prec = float(precision_score(y_true, y_pred, average='macro', zero_division=0) * 100.0)
            rec = float(recall_score(y_true, y_pred, average='macro', zero_division=0) * 100.0)
            f1 = float(f1_score(y_true, y_pred, average='macro', zero_division=0) * 100.0)
        else:
            # Native calculation
            classes = np.unique(np.concatenate([y_true, y_pred]))
            precs, recs, f1s = [], [], []
            for c in classes:
                tp = np.sum((y_pred == c) & (y_true == c))
                fp = np.sum((y_pred == c) & (y_true != c))
                fn = np.sum((y_pred != c) & (y_true == c))

                p = tp / max(1, (tp + fp))
                r = tp / max(1, (tp + fn))
                f = (2 * p * r) / max(1e-6, (p + r))
                precs.append(p)
                recs.append(r)
                f1s.append(f)

            prec = float(np.mean(precs) * 100.0)
            rec = float(np.mean(recs) * 100.0)
            f1 = float(np.mean(f1s) * 100.0)

        return acc, prec, rec, f1

    def record_episode(self, y_true: np.ndarray, y_pred: np.ndarray,
                       mae: float, rmse: float, dtse: float,
                       spatial_cov_pct: float, uav_flight_time_min: float,
                       energy_kj: float, comm_overhead_kb: float,
                       detection_latency_ms: float, resource_saving_pct: float):
        """Records comprehensive episode performance metrics."""
        acc, prec, rec, f1 = self.compute_classification_metrics(y_true, y_pred)

        record = {
            "accuracy": acc,
            "precision": prec,
            "recall": rec,
            "f1_score": f1,
            "prediction_mae": float(mae),
            "prediction_rmse": float(rmse),
            "digital_twin_sync_error": float(dtse),
            "spatial_coverage": float(spatial_cov_pct),
            "uav_flight_time": float(uav_flight_time_min),
            "energy_consumption": float(energy_kj),
            "communication_overhead": float(comm_overhead_kb),
            "anomaly_detection_latency": float(detection_latency_ms),
            "resource_saving_rate": float(resource_saving_pct)
        }
        self.episode_records.append(record)

    def get_summary(self) -> Dict[str, float]:
        """Returns the mean values for all 13 metrics across episodes."""
        if not self.episode_records:
            return {m: 0.0 for m in self.METRIC_NAMES}

        df = pd.DataFrame(self.episode_records)
        summary = {col: float(df[col].mean()) for col in self.METRIC_NAMES}
        return summary

    def get_dataframe(self) -> pd.DataFrame:
        """Returns episode-by-episode records as DataFrame."""
        return pd.DataFrame(self.episode_records)
