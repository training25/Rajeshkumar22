# -*- coding: utf-8 -*-
"""
Created on Tue Oct 27 10:28:33 2026

@author: ADMIN
"""

#!/usr/bin/env python3
"""
Generate 13 separate bar graphs
- Times New Roman (Liberation Serif), bold, fontsize 18
- Y-axis label present
- No title
- No value labels on bars
- No rotation on x-axis labels
"""

import matplotlib.pyplot as plt
import matplotlib
import numpy as np
import os

# Font settings
matplotlib.rcParams['font.family'] = 'Times New Roman'
matplotlib.rcParams['font.weight'] = 'bold'
matplotlib.rcParams['font.size'] = 20
matplotlib.rcParams['axes.labelsize'] = 20
matplotlib.rcParams['xtick.labelsize'] = 18
matplotlib.rcParams['ytick.labelsize'] = 18
matplotlib.rcParams['axes.labelweight'] = 'bold'

# Methods
labels = [
    "Proposed\n(DT + Adaptive UAV\n+ SFQL-BHOA)",
    "Uniform UAV +\nCentralized ML",
    "IoT-Only\nMonitoring\n(No UAV)",
    "Unsecured\nStandard FedAvg"
]

# Colors matching original: Green, Orange, Purple, Magenta
colors = ["#2ca02c", "#ff7f0e", "#9467bd", "#e377c2"]

# Data for all 13 metrics
metrics = [
    {
        "ylabel": "Accuracy (%)",
        "values": [97, 91.56, 78.44, 86.25],
        "filename": "01_accuracy.png"
    },
    {
        "ylabel": "Precision (%)",
        "values": [97, 85.03, 43.96, 75.65],
        "filename": "02_precision.png"
    },
    {
        "ylabel": "Recall (%)",
        "values": [98, 93.33, 47.29, 87.07],
        "filename": "03_recall.png"
    },
    {
        "ylabel": "F1-Score (%)",
        "values": [98, 87.94, 44.79, 78.94],
        "filename": "04_f1_score.png"
    },
    {
        "ylabel": "Prediction MAE",
        "values": [3.25, 3.74, 6.50, 4.10],
        "filename": "05_prediction_mae.png"
    },
    {
        "ylabel": "Prediction RMSE",
        "values": [5.76, 7.15, 12.12, 7.77],
        "filename": "06_prediction_rmse.png"
    },
    {
        "ylabel": "Digital Twin Sync Error (DTSE)",
        "values": [0.07, 0.10, 0.14, 0.10],
        "filename": "07_dtse.png"
    },
    {
        "ylabel": "Spatial Coverage (%)",
        "values": [35.94, 100.00, 37.50, 50.00],
        "filename": "08_spatial_coverage.png"
    },
    {
        "ylabel": "UAV Flight Time (min)",
        "values": [5.39, 10.09, 12, 16.03],
        "filename": "09_uav_flight_time.png"
    },
    {
        "ylabel": "Energy Consumption (kJ)",
        "values": [49.21, 94.78, 98.00, 141.89],
        "filename": "10_energy_consumption.png"
    },
    {
        "ylabel": "Communication Overhead (KB)",
        "values": [1338.35, 5184.00, 36.00, 1890.00],
        "filename": "11_communication_overhead.png"
    },
    {
        "ylabel": "Detection Latency (ms)",
        "values": [2749.11, 8.87, 3.87, 3.40],
        "filename": "12_detection_latency.png"
    },
    {
        "ylabel": "Resource-Saving Rate (%)",
        "values": [22.63, 18.50, 12.00, 26.30],
        "filename": "13_resource_saving_rate.png"
    },
]

output_dir = "separate_13_graphs"
os.makedirs(output_dir, exist_ok=True)

for metric in metrics:
    fig, ax = plt.subplots(figsize=(9, 6))
    
    x = np.arange(len(labels))
    ax.bar(x, metric["values"], color=colors, edgecolor="black", linewidth=0.8, width=0.65)
    
    # Y-axis limits with padding
    vals = metric["values"]
    ymin = min(0, min(vals))
    ymax = max(0, max(vals))
    yrange = ymax - ymin if ymax != ymin else 1.0
    padding = yrange * 0.15
    if ymin < 0:
        ax.set_ylim(ymin - padding * 0.5, ymax + padding * 0.3)
    else:
        ax.set_ylim(0, ymax + padding)
    
    # X-axis (no rotation)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontweight="bold", fontsize=16, fontfamily="Times New Roman")
    
    # Y-axis label
    ax.set_ylabel(metric["ylabel"], fontweight="bold", fontsize=20, fontfamily="Times New Roman")
    
    # Grid
    ax.yaxis.grid(True, linestyle="--", alpha=0.7)
    ax.set_axisbelow(True)
    
    # Spines
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    
    # Make y-tick labels bold
    for label in ax.get_yticklabels():
        label.set_fontweight("bold")
        label.set_fontsize(16)
        label.set_fontfamily("Times New Roman")
    
    plt.tight_layout()
    
    out_path = os.path.join(output_dir, metric["filename"])
    plt.savefig(out_path, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close()
    print(f"Saved: {out_path}")

print(f"\nAll 13 graphs saved to {output_dir}/")