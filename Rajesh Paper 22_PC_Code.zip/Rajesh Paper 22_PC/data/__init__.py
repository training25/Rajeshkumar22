"""
Data Module for Precision Agriculture Digital Twin.
Simulates heterogeneous IoT ground sensors and multispectral UAV aerial imagery.
"""

from .data_generator import FarmEnvironmentGenerator, CropStressType

__all__ = ['FarmEnvironmentGenerator', 'CropStressType']
