"""
Physical Farm Environment & Synthetic Heterogeneous Sensor Generator.
Models spatial soil parameters (moisture, temperature, pH, NPK),
atmospheric factors, sparse IoT sensor deployments, multispectral aerial reflectance,
and realistic dynamic crop stress propagation (drought, deficiency, pathogen outbreaks).
"""

import enum
import numpy as np
from typing import Dict, List, Tuple, Any


class CropStressType(enum.IntEnum):
    HEALTHY = 0
    WATER_STRESS = 1
    NUTRIENT_DEFICIENCY = 2
    PATHOGEN_DISEASE = 3
    THERMAL_STRESS = 4


class FarmEnvironmentGenerator:
    """
    Simulates the ground-truth physical state of the agricultural field
    and generates readings for both sparse IoT sensors and UAV multispectral cameras.
    """
    def __init__(self, config: dict):
        self.config = config
        self.rows = config['farm']['grid_rows']
        self.cols = config['farm']['grid_cols']
        self.num_zones = self.rows * self.cols
        self.num_sensors = config['farm']['num_iot_sensors']

        # Select fixed locations for the sparse IoT sensors (e.g. 24 of 64 zones)
        np.random.seed(42)
        all_zone_ids = np.arange(self.num_zones)
        # Evenly spread IoT sensors across the field
        stride = self.num_zones // self.num_sensors
        self.sensor_zone_ids = np.sort(np.random.choice(all_zone_ids, size=self.num_sensors, replace=False))
        self.sensor_mask = np.zeros(self.num_zones, dtype=bool)
        self.sensor_mask[self.sensor_zone_ids] = True

        # Zone coordinates in meters (center of each parcel)
        zone_w = config['farm']['width_m'] / self.cols
        zone_h = config['farm']['height_m'] / self.rows
        self.zone_coords = []
        for r in range(self.rows):
            for c in range(self.cols):
                cx = (c + 0.5) * zone_w
                cy = (r + 0.5) * zone_h
                self.zone_coords.append((cx, cy))
        self.zone_coords = np.array(self.zone_coords)

        # Baseline crop parameters
        self.crop_cfg = config['crop_parameters']
        
        # State tensors: (num_zones, features)
        # Features: [moisture, soil_temp, ph, ambient_temp, humidity, N, P, K, EC]
        self.feature_names = [
            "Soil_Moisture_pct", "Soil_Temp_C", "Soil_pH",
            "Ambient_Temp_C", "Humidity_pct", "Nitrogen_mg_kg",
            "Phosphorus_mg_kg", "Potassium_mg_kg", "EC_dS_m"
        ]
        self.num_features = len(self.feature_names)
        self.current_physical_state = np.zeros((self.num_zones, self.num_features))
        self.current_stress_labels = np.zeros(self.num_zones, dtype=int)
        
        # Initialize physical field
        self.reset()

    def reset(self, random_seed: int = None):
        """Resets the physical field with heterogeneous spatial zones and stress patches."""
        if random_seed is not None:
            np.random.seed(random_seed)

        # Base ambient parameters
        ambient_temp = 25.0 + np.random.normal(0.0, 1.5)
        humidity = 60.0 + np.random.normal(0.0, 5.0)

        for z in range(self.num_zones):
            # Spatial gradients
            r, c = divmod(z, self.cols)
            spatial_moisture_bias = -3.0 * (r / self.rows) + 2.0 * (c / self.cols)
            
            moisture = self.crop_cfg['optimal_soil_moisture_pct'] + spatial_moisture_bias + np.random.normal(0.0, 1.5)
            soil_temp = self.crop_cfg['optimal_soil_temp_c'] + np.random.normal(0.0, 1.0)
            ph = self.crop_cfg['optimal_soil_ph'] + np.random.normal(0.0, 0.2)
            n_val = self.crop_cfg['optimal_nitrogen_mg_kg'] + np.random.normal(0.0, 4.0)
            p_val = self.crop_cfg['optimal_phosphorus_mg_kg'] + np.random.normal(0.0, 3.0)
            k_val = self.crop_cfg['optimal_potassium_mg_kg'] + np.random.normal(0.0, 10.0)
            ec_val = 1.2 + np.random.normal(0.0, 0.1)

            self.current_physical_state[z] = [
                np.clip(moisture, 10.0, 45.0),
                soil_temp,
                np.clip(ph, 4.5, 8.5),
                ambient_temp + np.random.normal(0.0, 0.5),
                np.clip(humidity + np.random.normal(0.0, 2.0), 30.0, 95.0),
                max(5.0, n_val),
                max(5.0, p_val),
                max(20.0, k_val),
                max(0.1, ec_val)
            ]
            self.current_stress_labels[z] = CropStressType.HEALTHY

        # Inject realistic agricultural stress hotspots:
        self._inject_stress_hotspots()
        return self.current_physical_state, self.current_stress_labels

    def _inject_stress_hotspots(self):
        """Creates realistic clustered stress zones (water stress, nutrient deficit, pathogen)."""
        # 1. Water Stress Patch (e.g. broken drip line or sandy soil pocket)
        water_stress_center = np.random.randint(0, self.num_zones)
        dists = np.linalg.norm(self.zone_coords - self.zone_coords[water_stress_center], axis=1)
        water_stress_zones = np.where(dists < 90.0)[0]
        for z in water_stress_zones:
            self.current_physical_state[z, 0] = np.random.uniform(11.0, 17.5) # Critical moisture deficit
            self.current_physical_state[z, 1] += 3.5 # Soil heating up
            self.current_stress_labels[z] = CropStressType.WATER_STRESS

        # 2. Nutrient Deficiency Patch (e.g. low nitrogen leached zone)
        nutrient_center = np.random.randint(0, self.num_zones)
        dists = np.linalg.norm(self.zone_coords - self.zone_coords[nutrient_center], axis=1)
        nutrient_zones = [z for z in np.where(dists < 80.0)[0] if self.current_stress_labels[z] == CropStressType.HEALTHY]
        for z in nutrient_zones:
            self.current_physical_state[z, 5] = np.random.uniform(10.0, 22.0) # Nitrogen deficiency
            self.current_physical_state[z, 6] = np.random.uniform(8.0, 18.0)  # Phosphorus deficiency
            self.current_stress_labels[z] = CropStressType.NUTRIENT_DEFICIENCY

        # 3. Pathogen / Fungal Disease Hotspot (e.g. blight or rust spreading radially)
        disease_center = np.random.randint(0, self.num_zones)
        dists = np.linalg.norm(self.zone_coords - self.zone_coords[disease_center], axis=1)
        disease_zones = [z for z in np.where(dists < 70.0)[0] if self.current_stress_labels[z] == CropStressType.HEALTHY]
        for z in disease_zones:
            self.current_stress_labels[z] = CropStressType.PATHOGEN_DISEASE

        # 4. Thermal / Heat Stress Pocket
        thermal_zones = [z for z in range(self.num_zones) if self.current_stress_labels[z] == CropStressType.HEALTHY and np.random.rand() < 0.12]
        for z in thermal_zones:
            self.current_physical_state[z, 1] += 5.0 # Elevated soil temp
            self.current_physical_state[z, 3] += 4.5 # Elevated canopy temp
            self.current_stress_labels[z] = CropStressType.THERMAL_STRESS

    def step_time(self, delta_hours: float = 1.0):
        """Evolves the physical farm environment over time (diurnal cycle, evaporation, disease diffusion)."""
        for z in range(self.num_zones):
            # Natural evapotranspiration loss
            evap = 0.15 * delta_hours
            self.current_physical_state[z, 0] = max(8.0, self.current_physical_state[z, 0] - evap)

            # Re-evaluate water stress if moisture drops below threshold
            if self.current_physical_state[z, 0] < self.crop_cfg['water_stress_threshold_pct'] and self.current_stress_labels[z] == CropStressType.HEALTHY:
                self.current_stress_labels[z] = CropStressType.WATER_STRESS

        # Disease diffusion: infected zones have probability of infecting neighbors
        disease_indices = np.where(self.current_stress_labels == CropStressType.PATHOGEN_DISEASE)[0]
        for d_z in disease_indices:
            for other_z in range(self.num_zones):
                if self.current_stress_labels[other_z] == CropStressType.HEALTHY:
                    dist = np.linalg.norm(self.zone_coords[d_z] - self.zone_coords[other_z])
                    if dist < 65.0 and np.random.rand() < (0.08 * delta_hours):
                        self.current_stress_labels[other_z] = CropStressType.PATHOGEN_DISEASE

    def get_sparse_iot_readings(self, noise_std: float = 0.05) -> Dict[int, np.ndarray]:
        """
        Returns readings from the 24 sparse IoT sensor stations with measurement noise.
        Other 40 zones return None / unobserved.
        """
        readings = {}
        for z in self.sensor_zone_ids:
            true_vals = self.current_physical_state[z].copy()
            noise = np.random.normal(0.0, noise_std * np.abs(true_vals) + 1e-4)
            readings[z] = true_vals + noise
        return readings

    def get_multispectral_image_for_zone(self, zone_id: int) -> np.ndarray:
        """
        Simulates UAV 5-band multispectral reflectance array (Red, Green, Blue, RedEdge, NIR).
        Reflectance values in [0.0, 1.0] representing canopy spectral response.
        """
        stress = self.current_stress_labels[zone_id]
        noise = np.random.normal(0.0, 0.02, size=5)

        if stress == CropStressType.HEALTHY:
            # Healthy: Low Red/Blue, moderate Green, high RedEdge and very high NIR
            # NDVI ~ 0.80, NDRE ~ 0.40
            bands = np.array([0.08, 0.16, 0.06, 0.32, 0.68])
        elif stress == CropStressType.WATER_STRESS:
            # Water stress: Chlorophyll remains, but mesophyll cells shrink -> NIR drops, Red rises
            # NDVI ~ 0.52
            bands = np.array([0.16, 0.19, 0.10, 0.28, 0.48])
        elif stress == CropStressType.NUTRIENT_DEFICIENCY:
            # Chlorosis (yellowing): Green and Red rise, RedEdge drops, NIR moderate
            # NDRE ~ 0.18, NDVI ~ 0.48
            bands = np.array([0.18, 0.24, 0.12, 0.22, 0.44])
        elif stress == CropStressType.PATHOGEN_DISEASE:
            # Necrosis and leaf tissue destruction: Red and Blue rise, NIR drops drastically
            # NDVI ~ 0.25
            bands = np.array([0.25, 0.22, 0.18, 0.20, 0.32])
        else: # THERMAL_STRESS
            # Canopy heating: slight spectral shift
            # NDVI ~ 0.62
            bands = np.array([0.12, 0.18, 0.08, 0.30, 0.56])

        spectral_signature = np.clip(bands + noise, 0.01, 0.99)
        return spectral_signature

    def get_all_multispectral_images(self) -> np.ndarray:
        """Returns 5-band multispectral data for all zones: shape (num_zones, 5)."""
        images = np.zeros((self.num_zones, 5))
        for z in range(self.num_zones):
            images[z] = self.get_multispectral_image_for_zone(z)
        return images
