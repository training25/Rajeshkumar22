"""
Zheng-Style Cryptographic Signcryption Scheme.
Jointly signs and encrypts agricultural IoT messages and Federated Q-Learning weights
in a single efficient cryptographic step using Schnorr-Zheng signature dynamics,
guaranteeing confidentiality, authenticity, integrity, and non-repudiation with ZERO modular inverse risk.
"""

import os
import time
import hmac
import hashlib
import json
import numpy as np
from typing import Tuple, Dict, Any, Optional

# Certified 256-bit Prime Field Modulus (secp256k1 field prime)
# 2^256 - 2^32 - 977
SEC_P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
SEC_Q = SEC_P - 1 # Modulus for exponent arithmetic (Fermat's Little Theorem)
SEC_G = 3         # Generator of group


class SecureMessage:
    """Encapsulates a signcrypted ciphertext packet."""
    def __init__(self, sender_id: str, ciphertext: bytes,
                 auth_tag: bytes, r_param: bytes, timestamp: float):
        self.sender_id = sender_id
        self.ciphertext = ciphertext
        self.auth_tag = auth_tag
        self.r_param = r_param
        self.timestamp = timestamp

    @property
    def total_bytes(self) -> int:
        return len(self.ciphertext) + len(self.auth_tag) + len(self.r_param) + 16


class ZhengSigncryption:
    """
    Implements a discrete-logarithm Zheng Signcryption engine.
    Uses Schnorr-Zheng dynamics: s = (v - x_A * r) mod (p - 1),
    eliminating division/modular inversions entirely to guarantee 100% numerical robustness.
    """
    def __init__(self, entity_id: str, private_key: int = None):
        self.entity_id = entity_id
        self.p = SEC_P
        self.q = SEC_Q
        self.g = SEC_G

        # Keypair generation: x in [1, p-2]
        if private_key is None:
            self.x = int.from_bytes(os.urandom(32), byteorder='big') % (self.q - 1) + 1
        else:
            self.x = private_key % (self.q - 1) + 1

        # Public key: y = g^x mod p
        self.y = pow(self.g, self.x, self.p)

    def _kdf(self, shared_secret_int: int) -> Tuple[bytes, bytes]:
        """Derives encryption key (K1) and authentication key (K2) via SHA-256."""
        secret_bytes = shared_secret_int.to_bytes((shared_secret_int.bit_length() + 7) // 8, byteorder='big')
        h1 = hashlib.sha256(secret_bytes + b"ENC").digest()
        h2 = hashlib.sha256(secret_bytes + b"MAC").digest()
        return h1, h2

    def signcrypt(self, plaintext_data: Any, receiver_public_key: int) -> Tuple[SecureMessage, float]:
        """
        Signs and encrypts data in a single logical operation.
        Returns: (SecureMessage, execution_latency_ms)
        """
        t0 = time.time()

        # Serialize payload to JSON bytes
        if isinstance(plaintext_data, (dict, list)):
            payload_bytes = json.dumps(plaintext_data).encode('utf-8')
        elif isinstance(plaintext_data, np.ndarray):
            payload_bytes = json.dumps(plaintext_data.tolist()).encode('utf-8')
        elif isinstance(plaintext_data, str):
            payload_bytes = plaintext_data.encode('utf-8')
        else:
            payload_bytes = str(plaintext_data).encode('utf-8')

        # 1. Ephemeral random key v in [1, q-1]
        v = int.from_bytes(os.urandom(32), byteorder='big') % (self.q - 1) + 1

        # 2. Key agreement: k = (y_B)^v mod p
        k = pow(receiver_public_key, v, self.p)
        k_enc, k_mac = self._kdf(k)

        # 3. Symmetric encryption (Stream cipher keystream)
        keystream = hashlib.sha256(k_enc + b"STREAM").digest()
        while len(keystream) < len(payload_bytes):
            keystream += hashlib.sha256(keystream + b"NEXT").digest()
        ciphertext = bytes([p ^ kb for p, kb in zip(payload_bytes, keystream[:len(payload_bytes)])])

        # 4. Hash commitment r = H(ciphertext, k_mac) mod (p - 1)
        r_hash = hashlib.sha256(ciphertext + k_mac).digest()
        r_int = int.from_bytes(r_hash, byteorder='big') % self.q
        if r_int == 0:
            r_int = 1

        # 5. Signature component s = (v - x_A * r) mod (p - 1)
        # Schnorr-Zheng signature: no division, no modular inverse needed!
        s = (v - self.x * r_int) % self.q
        s_bytes = s.to_bytes(32, byteorder='big')
        r_bytes = r_int.to_bytes(32, byteorder='big')

        # 6. HMAC tag for integrity
        auth_tag = hmac.new(k_mac, ciphertext + r_bytes + s_bytes, hashlib.sha256).digest()

        msg = SecureMessage(
            sender_id=self.entity_id,
            ciphertext=ciphertext,
            auth_tag=auth_tag,
            r_param=r_bytes + s_bytes,
            timestamp=time.time()
        )
        latency_ms = (time.time() - t0) * 1000.0
        return msg, latency_ms

    def unsigncrypt(self, message: SecureMessage, sender_public_key: int) -> Tuple[Optional[Any], bool, float]:
        """
        Unsigncrypts and verifies authenticity of the message.
        Returns: (recovered_data, is_valid, execution_latency_ms)
        """
        t0 = time.time()
        try:
            r_bytes = message.r_param[:32]
            s_bytes = message.r_param[32:]
            r_int = int.from_bytes(r_bytes, byteorder='big')
            s = int.from_bytes(s_bytes, byteorder='big')

            # 1. Recover shared secret:
            # g^v = (g^s * y_A^r) mod p
            # k = (g^v)^x_B mod p == (y_B)^v mod p
            g_s = pow(self.g, s, self.p)
            y_r = pow(sender_public_key, r_int, self.p)
            g_v = (g_s * y_r) % self.p
            k = pow(g_v, self.x, self.p)

            k_enc, k_mac = self._kdf(k)

            # 2. Verify MAC tag
            expected_tag = hmac.new(k_mac, message.ciphertext + r_bytes + s_bytes, hashlib.sha256).digest()
            if not hmac.compare_digest(expected_tag, message.auth_tag):
                return None, False, (time.time() - t0) * 1000.0

            # 3. Decrypt payload
            keystream = hashlib.sha256(k_enc + b"STREAM").digest()
            while len(keystream) < len(message.ciphertext):
                keystream += hashlib.sha256(keystream + b"NEXT").digest()
            decrypted_bytes = bytes([c ^ kb for c, kb in zip(message.ciphertext, keystream[:len(message.ciphertext)])])

            # 4. Verify hash commitment r == H(ciphertext, k_mac)
            expected_r_hash = hashlib.sha256(message.ciphertext + k_mac).digest()
            expected_r_int = int.from_bytes(expected_r_hash, byteorder='big') % self.q
            if expected_r_int == 0:
                expected_r_int = 1

            if r_int != expected_r_int:
                return None, False, (time.time() - t0) * 1000.0

            # Deserialize JSON
            data = json.loads(decrypted_bytes.decode('utf-8'))
            latency_ms = (time.time() - t0) * 1000.0
            return data, True, latency_ms

        except Exception:
            return None, False, (time.time() - t0) * 1000.0
