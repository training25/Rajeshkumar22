"""
Energy-Efficient UAV Aerial Sensing and Adaptive Mission Planner.
Implements realistic aerodynamic power consumption and compares
exhaustive uniform field scanning against Digital Twin-guided adaptive scanning.
"""

import numpy as np
from typing import List, Tuple, Dict, Any


class FlightScanResult:
    """Stores telemetry, metrics, and trajectory of an aerial scanning mission."""
    def __init__(self, mode: str, visited_zone_ids: List[int],
                 trajectory_coords: np.ndarray, total_flight_time_sec: float,
                 total_energy_joules: float, comm_overhead_kb: float,
                 spatial_coverage_pct: float):
        self.mode = mode
        self.visited_zone_ids = visited_zone_ids
        self.trajectory_coords = trajectory_coords
        self.total_flight_time_sec = total_flight_time_sec
        self.total_energy_joules = total_energy_joules
        self.comm_overhead_kb = comm_overhead_kb
        self.spatial_coverage_pct = spatial_coverage_pct

    @property
    def flight_time_minutes(self) -> float:
        return self.total_flight_time_sec / 60.0

    @property
    def energy_kj(self) -> float:
        return self.total_energy_joules / 1000.0


class UAVMissionPlanner:
    """
    Simulates UAV physics, aerodynamics, and mission routing for precision agriculture.
    """
    def __init__(self, config: dict, zone_coords: np.ndarray):
        self.config = config
        self.uav_cfg = config['uav']
        self.zone_coords = zone_coords
        self.num_zones = len(zone_coords)

        # Kinematic & Aerodynamic parameters
        self.cruise_speed = self.uav_cfg['cruise_speed_mps']
        self.altitude = self.uav_cfg['altitude_m']
        self.p0 = self.uav_cfg['energy_model']['blade_profile_power_p0']
        self.pi = self.uav_cfg['energy_model']['induced_power_pi']
        self.u_tip = self.uav_cfg['energy_model']['tip_speed_u_tip']
        self.drag_ratio = self.uav_cfg['energy_model']['fuselage_drag_ratio']
        self.payload_power = self.uav_cfg['payload_power_watts']
        self.comm_power = self.uav_cfg['comm_power_watts']
        self.scan_time_per_zone = self.uav_cfg['scan_time_per_zone_sec']
        self.battery_capacity = self.uav_cfg['battery_capacity_joules']

        # Base station location (corner of the farm: [0, 0, 0])
        self.base_station = np.array([0.0, 0.0])

    def compute_flight_power(self, speed_mps: float) -> float:
        """
        Computes rotary-wing UAV power consumption (Watts) as a function of airspeed V.
        Based on standard aerodynamic propulsion models.
        """
        v = speed_mps
        # Blade profile power
        p_blade = self.p0 * (1.0 + (3.0 * v**2) / (self.u_tip**2))
        
        # Induced power
        v0 = 4.03 # Mean rotor induced velocity
        term1 = np.sqrt(1.0 + (v**4) / (4.0 * v0**4))
        term2 = (v**2) / (2.0 * v0**2)
        p_induced = self.pi * np.sqrt(max(0.0, term1 - term2))

        # Parasite drag power
        p_parasite = 0.5 * self.drag_ratio * 1.225 * 0.5 * 0.06 * (v**3)

        total_propulsion_power = p_blade + p_induced + p_parasite
        return float(total_propulsion_power)

    def _solve_tsp_greedy(self, target_zone_ids: List[int]) -> List[int]:
        """
        Greedy Nearest-Neighbor heuristic to plan flight trajectory
        visiting selected target zones starting from base station.
        """
        if not target_zone_ids:
            return []

        unvisited = list(target_zone_ids)
        current_pos = self.base_station
        ordered_route = []

        while unvisited:
            dists = [np.linalg.norm(self.zone_coords[z] - current_pos) for z in unvisited]
            nearest_idx = int(np.argmin(dists))
            best_zone = unvisited.pop(nearest_idx)
            ordered_route.append(best_zone)
            current_pos = self.zone_coords[best_zone]

        return ordered_route

    def execute_uniform_scanning(self) -> FlightScanResult:
        """
        Exhaustive Baseline: UAV scans all 64 zones in a uniform grid/lawnmower pattern.
        """
        all_zones = list(range(self.num_zones))
        # Lawnmower ordering
        route = self._solve_tsp_greedy(all_zones)
        return self._simulate_flight_mission(route, mode="Uniform_Exhaustive")

    def execute_adaptive_scanning(self, priority_scores: np.ndarray,
                                  top_k_fraction: float = 0.35) -> FlightScanResult:
        """
        Proposed Adaptive Scanning: UAV visits only high-priority / anomalous zones
        flagged by the Digital Twin, drastically conserving flight time and battery.
        """
        k = max(5, int(np.ceil(top_k_fraction * self.num_zones)))
        # Sort zones by priority score (descending)
        ranked_zones = np.argsort(-priority_scores)
        target_zones = list(ranked_zones[:k])

        route = self._solve_tsp_greedy(target_zones)
        return self._simulate_flight_mission(route, mode="Adaptive_Priority")

    def _simulate_flight_mission(self, route_zone_ids: List[int], mode: str) -> FlightScanResult:
        """Simulates physical UAV flight across the planned waypoints."""
        if not route_zone_ids:
            return FlightScanResult(mode, [], np.array([]), 0.0, 0.0, 0.0, 0.0)

        flight_power = self.compute_flight_power(self.cruise_speed)
        hover_power = self.compute_flight_power(0.0)

        current_pos = self.base_station
        total_time_sec = 0.0
        total_energy_joules = 0.0
        trajectory = [np.append(current_pos, self.altitude)]

        for z in route_zone_ids:
            target_pos = self.zone_coords[z]
            dist = np.linalg.norm(target_pos - current_pos)
            
            # Flight leg to zone
            leg_time = dist / self.cruise_speed
            leg_energy = leg_time * (flight_power + self.payload_power + self.comm_power)
            
            # Hovering & scanning at zone
            scan_time = self.scan_time_per_zone
            scan_energy = scan_time * (hover_power + self.payload_power + self.comm_power)

            total_time_sec += (leg_time + scan_time)
            total_energy_joules += (leg_energy + scan_energy)

            trajectory.append(np.append(target_pos, self.altitude))
            current_pos = target_pos

        # Return to base station
        return_dist = np.linalg.norm(self.base_station - current_pos)
        return_time = return_dist / self.cruise_speed
        return_energy = return_time * (flight_power + self.payload_power + self.comm_power)
        
        total_time_sec += return_time
        total_energy_joules += return_energy
        trajectory.append(np.append(self.base_station, 0.0))

        # Communication overhead: 5-band compressed multispectral image ~ 45 KB per scanned zone
        comm_overhead_kb = len(route_zone_ids) * 45.0
        spatial_coverage_pct = (len(route_zone_ids) / self.num_zones) * 100.0

        return FlightScanResult(
            mode=mode,
            visited_zone_ids=route_zone_ids,
            trajectory_coords=np.array(trajectory),
            total_flight_time_sec=total_time_sec,
            total_energy_joules=total_energy_joules,
            comm_overhead_kb=comm_overhead_kb,
            spatial_coverage_pct=spatial_coverage_pct
        )
