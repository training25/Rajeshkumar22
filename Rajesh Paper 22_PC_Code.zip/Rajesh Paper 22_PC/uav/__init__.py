"""
UAV Control and Energy-Efficient Aerial Scanning Module.
Implements aerodynamic energy modeling and adaptive priority-driven field scanning.
"""

from .uav_controller import UAVMissionPlanner, FlightScanResult

__all__ = ['UAVMissionPlanner', 'FlightScanResult']
