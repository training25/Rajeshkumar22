"""
Signcryption-Enabled Federated Q-Learning (SFQL) with Bounty Hunter Optimization (BHOA).
Enables privacy-preserving, authenticated, and distributed crop stress diagnosis
across agricultural edge cluster gateways without exposing raw field sensor data.
"""

import copy
import time
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Tuple, Any

from security.signcryption import ZhengSigncryption, SecureMessage
from .bounty_hunter_optimizer import BountyHunterOptimizer


class CropStressQNetwork(nn.Module):
    """
    Deep Q-Network for Agricultural Crop Stress Diagnosis.
    Maps fused Digital Twin soil parameters and aerial semantic features
    to Q-values across 5 crop condition states.
    """
    def __init__(self, in_features: int = 16, num_classes: int = 5):
        super(CropStressQNetwork, self).__init__()
        self.fc1 = nn.Linear(in_features, 64)
        self.bn1 = nn.BatchNorm1d(64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Handles single instance or batch
        if x.dim() == 1:
            x = x.unsqueeze(0)
        h = F.relu(self.bn1(self.fc1(x)))
        h = F.relu(self.fc2(h))
        q_vals = self.fc3(h)
        return q_vals


class LocalClusterQAgent:
    """
    Local Edge Gateway Agent operating in a farm quadrant.
    Learns crop stress patterns locally and signcrypts model updates.
    """
    def __init__(self, cluster_id: int, assigned_zones: List[int],
                 in_features: int = 16, num_classes: int = 5, lr: float = 0.02):
        self.cluster_id = cluster_id
        self.assigned_zones = assigned_zones
        self.in_features = in_features
        self.num_classes = num_classes

        # Neural Q-Network
        self.q_net = CropStressQNetwork(in_features, num_classes)
        self.optimizer = optim.Adam(self.q_net.parameters(), lr=lr)

        # Cryptographic Signcryption Engine
        self.crypto = ZhengSigncryption(entity_id=f"ClusterGateway_{cluster_id}")

        # Performance tracker
        self.local_accuracy = 0.0

    def get_q_values(self, features: np.ndarray) -> np.ndarray:
        """Returns Q-values for given state features."""
        self.q_net.eval()
        with torch.no_grad():
            t_in = torch.from_numpy(features).float()
            q_out = self.q_net(t_in)
            return q_out.cpu().numpy()

    def predict_stress_class(self, features: np.ndarray) -> np.ndarray:
        """Selects stress class with maximum Q-value: argmax_a Q(s, a)."""
        q_vals = self.get_q_values(features)
        return np.argmax(q_vals, axis=-1)

    def train_local_epoch(self, states: np.ndarray, labels: np.ndarray,
                          epochs: int = 4) -> float:
        """Trains local Q-network using Bellman temporal-difference cross-entropy."""
        if len(states) == 0:
            return 0.0

        self.q_net.train()
        t_states = torch.from_numpy(states).float()
        t_labels = torch.from_numpy(labels).long()

        total_loss = 0.0
        for _ in range(epochs):
            self.optimizer.zero_grad()
            q_values = self.q_net(t_states)
            loss = F.cross_entropy(q_values, t_labels)
            loss.backward()
            self.optimizer.step()
            total_loss += loss.item()

        # Update local accuracy
        with torch.no_grad():
            preds = torch.argmax(self.q_net(t_states), dim=-1)
            self.local_accuracy = float((preds == t_labels).float().mean().item())

        return total_loss / max(1, epochs)

    def export_signcrypted_weights(self, receiver_pubkey: int) -> Tuple[SecureMessage, float]:
        """
        Extracts Q-network parameter tensors and securely signcrypts them
        before wireless uplink to the Digital Twin.
        """
        weights_dict = {k: v.cpu().numpy().tolist() for k, v in self.q_net.state_dict().items()}
        secure_msg, crypto_latency_ms = self.crypto.signcrypt(weights_dict, receiver_pubkey)
        return secure_msg, crypto_latency_ms


class SigncryptedFederatedQLearning:
    """
    Central Digital Twin Federated Learning Coordinator.
    Coordinates distributed Q-agents, verifies signcrypted model updates,
    and performs BHOA-optimized Federated Model Aggregation.
    """
    def __init__(self, config: dict, zone_coords: np.ndarray):
        self.config = config
        self.num_clusters = config['farm']['num_clusters']
        self.num_zones = len(zone_coords)

        # Assign zones into 4 spatial quadrants
        self.cluster_agents: List[LocalClusterQAgent] = []
        cx_mid = config['farm']['width_m'] / 2.0
        cy_mid = config['farm']['height_m'] / 2.0

        for c_id in range(self.num_clusters):
            assigned = []
            for z, (x, y) in enumerate(zone_coords):
                if c_id == 0 and x < cx_mid and y < cy_mid:
                    assigned.append(z)
                elif c_id == 1 and x >= cx_mid and y < cy_mid:
                    assigned.append(z)
                elif c_id == 2 and x < cx_mid and y >= cy_mid:
                    assigned.append(z)
                elif c_id == 3 and x >= cx_mid and y >= cy_mid:
                    assigned.append(z)

            agent = LocalClusterQAgent(
                cluster_id=c_id,
                assigned_zones=assigned,
                in_features=16,
                num_classes=config['signcryption_federated_ql']['num_classes'],
                lr=config['signcryption_federated_ql']['learning_rate']
            )
            self.cluster_agents.append(agent)

        # Central Digital Twin Server Keypair
        self.server_crypto = ZhengSigncryption(entity_id="DigitalTwin_Central_Server")

        # Global Unified Q-Network
        self.global_q_net = CropStressQNetwork(in_features=16, num_classes=5)
        self.sync_local_agents_with_global()

        # Bounty Hunter Optimizer (BHOA) for Aggregation Weights
        bhoa_cfg = config['bounty_hunter_optimizer']
        self.bhoa = BountyHunterOptimizer(
            population_size=bhoa_cfg['population_size'],
            max_iter=bhoa_cfg['max_iterations'],
            dim=self.num_clusters,
            lb=0.01,
            ub=1.0,
            posse_cooperation_rate=bhoa_cfg['posse_cooperation_rate'],
            trail_investigation_radius=bhoa_cfg['trail_investigation_radius'],
            trapping_threshold=bhoa_cfg['trapping_threshold']
        )
        self.aggregation_weights = np.ones(self.num_clusters) / self.num_clusters

    def sync_local_agents_with_global(self):
        """Distributes global weights to all local cluster agents."""
        global_state = self.global_q_net.state_dict()
        for agent in self.cluster_agents:
            agent.q_net.load_state_dict(copy.deepcopy(global_state))

    def train_federated_round(self, digital_twin_features: np.ndarray,
                              true_stress_labels: np.ndarray) -> Dict[str, Any]:
        """
        Executes one full round of Signcryption-Enabled Federated Q-Learning:
        1. Local training on cluster parcels.
        2. Cryptographic Signcryption of local Q-network weights.
        3. Central Server Unsigncryption & Authenticity verification.
        4. Bounty Hunter Optimization (BHOA) for optimal aggregation weighting.
        5. Model aggregation and global broadcast.
        """
        t0 = time.time()
        local_losses = []
        signcrypted_messages = []
        crypto_latencies_ms = []

        # 1. Local Training & Signcrypted Export
        for agent in self.cluster_agents:
            z_indices = agent.assigned_zones
            sub_states = digital_twin_features[z_indices]
            sub_labels = true_stress_labels[z_indices]

            loss = agent.train_local_epoch(sub_states, sub_labels, epochs=4)
            local_losses.append(loss)

            # Secure Signcryption
            sec_msg, lat = agent.export_signcrypted_weights(self.server_crypto.y)
            signcrypted_messages.append(sec_msg)
            crypto_latencies_ms.append(lat)

        # 2. Central Unsigncryption & Verification
        decrypted_cluster_weights = []
        for c_id, sec_msg in enumerate(signcrypted_messages):
            sender_pubkey = self.cluster_agents[c_id].crypto.y
            raw_weights, is_valid, unsign_lat = self.server_crypto.unsigncrypt(sec_msg, sender_pubkey)
            if not is_valid:
                raise ValueError(f"Security Alert: Signature verification failed for cluster {c_id}!")
            crypto_latencies_ms.append(unsign_lat)

            # Convert JSON lists back to torch tensors
            t_weights = {k: torch.tensor(v, dtype=torch.float32) for k, v in raw_weights.items()}
            decrypted_cluster_weights.append(t_weights)

        # 3. Bounty Hunter Optimization (BHOA) for Aggregation Weights
        local_accuracies = np.array([agent.local_accuracy for agent in self.cluster_agents])
        
        def bhoa_aggregation_objective(w: np.ndarray) -> float:
            # Objective: Maximize weighted accuracy while penalizing weight skew
            w_norm = w / (np.sum(w) + 1e-9)
            entropy = -np.sum(w_norm * np.log(w_norm + 1e-9))
            weighted_acc = np.dot(w_norm, local_accuracies)
            return float(weighted_acc + 0.1 * entropy)

        best_w, bounty = self.bhoa.optimize(
            objective_func=bhoa_aggregation_objective,
            seed_target=self.aggregation_weights
        )
        self.aggregation_weights = best_w / np.sum(best_w)

        # 4. BHOA-Weighted Federated Model Aggregation
        global_state = copy.deepcopy(self.global_q_net.state_dict())
        for key in global_state.keys():
            global_state[key] = torch.zeros_like(global_state[key], dtype=torch.float32)

        for c_id, c_weights in enumerate(decrypted_cluster_weights):
            w = float(self.aggregation_weights[c_id])
            for key in global_state.keys():
                global_state[key] += w * c_weights[key]

        self.global_q_net.load_state_dict(global_state)
        self.sync_local_agents_with_global()

        # Compute global predictions across all zones
        self.global_q_net.eval()
        with torch.no_grad():
            t_all = torch.from_numpy(digital_twin_features).float()
            q_all = self.global_q_net(t_all)
            preds = torch.argmax(q_all, dim=-1).cpu().numpy()
            probs = F.softmax(q_all, dim=-1).cpu().numpy()

        global_acc = float(np.mean(preds == true_stress_labels) * 100.0)
        round_duration_sec = time.time() - t0

        return {
            'mean_loss': float(np.mean(local_losses)),
            'global_accuracy': global_acc,
            'predictions': preds,
            'probabilities': probs,
            'aggregation_weights': self.aggregation_weights,
            'crypto_latency_ms': float(np.mean(crypto_latencies_ms)),
            'comm_overhead_kb': sum(msg.total_bytes for msg in signcrypted_messages) / 1024.0,
            'round_duration_sec': round_duration_sec
        }
