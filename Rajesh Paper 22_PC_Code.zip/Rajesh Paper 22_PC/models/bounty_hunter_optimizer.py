"""
Bounty Hunter Optimization Algorithm (BHOA).
A novel metaheuristic optimization algorithm inspired by the pursuit strategies
of bounty hunters: target tracking, informant clues via Lévy flight,
perimeter trap encirclement, and posse reward cooperation.
"""

import math
import numpy as np
from typing import Callable, Tuple, Optional


class BountyHunterOptimizer:
    """
    Implements the Bounty Hunter Optimization Algorithm (BHOA).
    Used in SFQL to:
    1. Optimize federated aggregation weights across agricultural edge clusters.
    2. Guide Q-learning network parameter tuning for multi-stress identification.
    """
    def __init__(self, population_size: int = 15, max_iter: int = 20,
                 dim: int = 4, lb: float = 0.01, ub: float = 1.0,
                 posse_cooperation_rate: float = 0.65,
                 trail_investigation_radius: float = 0.25,
                 trapping_threshold: float = 0.15):
        self.pop_size = population_size
        self.max_iter = max_iter
        self.dim = dim
        self.lb = np.ones(dim) * lb if np.isscalar(lb) else np.array(lb)
        self.ub = np.ones(dim) * ub if np.isscalar(ub) else np.array(ub)

        self.p_cooperation = posse_cooperation_rate
        self.investigation_radius = trail_investigation_radius
        self.trap_threshold = trapping_threshold

        # Internal state
        self.population = np.zeros((self.pop_size, self.dim))
        self.fitness = np.full(self.pop_size, -np.inf)
        self.prime_target = None
        self.bounty_reward = -np.inf
        self.convergence_history = []

    def _initialize_posse(self):
        """Phase 1: Mobilize Bounty Hunter Posse across Search Domain."""
        self.population = self.lb + np.random.rand(self.pop_size, self.dim) * (self.ub - self.lb)
        self.fitness = np.full(self.pop_size, -np.inf)
        self.prime_target = None
        self.bounty_reward = -np.inf
        self.convergence_history = []

    def _levy_flight(self, beta: float = 1.5) -> np.ndarray:
        """Mantegna's algorithm for heavy-tailed stochastic exploration (Trail Investigation)."""
        sigma_num = math.gamma(1.0 + beta) * math.sin(math.pi * beta / 2.0)
        sigma_den = math.gamma((1.0 + beta) / 2.0) * beta * (2.0 ** ((beta - 1.0) / 2.0))
        sigma_u = (sigma_num / sigma_den) ** (1.0 / beta)

        u = np.random.normal(0.0, sigma_u, size=self.dim)
        v = np.random.normal(0.0, 1.0, size=self.dim)
        step = u / (np.abs(v) ** (1.0 / beta))
        return step

    def optimize(self, objective_func: Callable[[np.ndarray], float],
                 seed_target: Optional[np.ndarray] = None) -> Tuple[np.ndarray, float]:
        """
        Executes BHOA optimization cycle.
        Maximizes objective_func (bounty reward).
        """
        self._initialize_posse()

        # Seed with initial solution if provided
        if seed_target is not None and len(seed_target) == self.dim:
            self.population[0] = np.clip(seed_target, self.lb, self.ub)

        # Initial evaluation
        for i in range(self.pop_size):
            self.fitness[i] = objective_func(self.population[i])
            if self.fitness[i] > self.bounty_reward:
                self.bounty_reward = self.fitness[i]
                self.prime_target = self.population[i].copy()

        self.convergence_history.append(self.bounty_reward)

        # Pursuit Loop
        for it in range(self.max_iter):
            # Dynamic encirclement shrinkage factor (linearly decreases from 2.0 to 0.0)
            a_factor = 2.0 * (1.0 - (it / self.max_iter))

            for i in range(self.pop_size):
                candidate = self.population[i].copy()

                # Phase 2: Informant Cues & Posse Collaboration
                if np.random.rand() < self.p_cooperation:
                    # Hunters share intelligence from fellow posse members
                    r_posse = np.random.randint(0, self.pop_size)
                    c_vec = 2.0 * np.random.rand(self.dim)
                    d_target = np.abs(c_vec * self.prime_target - self.population[i])
                    a_vec = 2.0 * a_factor * np.random.rand(self.dim) - a_factor
                    
                    # Phase 3: Trap Setting & Encirclement
                    candidate = self.prime_target - a_vec * d_target

                # Phase 4: Long-range Trail Investigation (Lévy flight exploration)
                else:
                    levy = self._levy_flight(beta=1.5)
                    step_size = self.investigation_radius * levy * (self.population[i] - self.prime_target)
                    candidate = self.population[i] + step_size

                # Boundary clipping
                candidate = np.clip(candidate, self.lb, self.ub)

                # Bounty Evaluation
                reward = objective_func(candidate)
                if reward > self.fitness[i]:
                    self.population[i] = candidate
                    self.fitness[i] = reward
                    if reward > self.bounty_reward:
                        self.bounty_reward = reward
                        self.prime_target = candidate.copy()

            self.convergence_history.append(self.bounty_reward)

        return self.prime_target, self.bounty_reward
