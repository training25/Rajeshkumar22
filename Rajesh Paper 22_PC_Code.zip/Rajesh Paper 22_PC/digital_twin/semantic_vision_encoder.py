"""
Semantic Vision Encoder (SVE) for Aerial Crop Imagery.
Extracts vegetation indices (NDVI, NDRE, SAVI, GNDVI) and learns dense semantic
crop canopy embeddings from 5-band multispectral imagery.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, Tuple


class SemanticVisionEncoder(nn.Module):
    """
    Deep Neural Network mapping raw multispectral aerial bands and vegetation indices
    into compact semantic feature embeddings for crop stress diagnosis.
    """
    def __init__(self, in_bands: int = 5, latent_dim: int = 32):
        super(SemanticVisionEncoder, self).__init__()
        self.in_bands = in_bands
        self.latent_dim = latent_dim

        # Input vector: 5 raw bands + 4 vegetation indices = 9 features
        in_features = in_bands + 4

        self.encoder_mlp = nn.Sequential(
            nn.Linear(in_features, 64),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, latent_dim),
            nn.LayerNorm(latent_dim)
        )

        # Canopy condition classifier head for auxiliary supervision
        self.stress_classifier = nn.Sequential(
            nn.Linear(latent_dim, 16),
            nn.ReLU(),
            nn.Linear(16, 5) # 5 stress classes
        )

    @staticmethod
    def compute_vegetation_indices(multispectral_bands: np.ndarray) -> np.ndarray:
        """
        Computes 4 key precision agriculture vegetation indices from bands:
        Bands: [0: Red, 1: Green, 2: Blue, 3: RedEdge, 4: NIR]
        Returns: [NDVI, NDRE, SAVI, GNDVI]
        """
        red = multispectral_bands[:, 0]
        green = multispectral_bands[:, 1]
        blue = multispectral_bands[:, 2]
        red_edge = multispectral_bands[:, 3]
        nir = multispectral_bands[:, 4]

        eps = 1e-6
        # 1. Normalized Difference Vegetation Index (NDVI)
        ndvi = (nir - red) / (nir + red + eps)

        # 2. Normalized Difference Red Edge Index (NDRE) - sensitive to chlorophyll in dense canopy
        ndre = (nir - red_edge) / (nir + red_edge + eps)

        # 3. Soil Adjusted Vegetation Index (SAVI) - minimizes soil brightness noise (L = 0.5)
        l = 0.5
        savi = ((1.0 + l) * (nir - red)) / (nir + red + l + eps)

        # 4. Green Normalized Difference Vegetation Index (GNDVI) - sensitive to water & nitrogen
        gndvi = (nir - green) / (nir + green + eps)

        indices = np.stack([ndvi, ndre, savi, gndvi], axis=1)
        return np.clip(indices, -1.0, 1.0)

    def forward(self, x_input: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        x_input: (batch_size, 9) containing 5 bands + 4 indices
        Returns: (latent_embeddings, class_logits)
        """
        latent = self.encoder_mlp(x_input)
        logits = self.stress_classifier(latent)
        return latent, logits

    def extract_features_numpy(self, multispectral_bands: np.ndarray) -> np.ndarray:
        """
        Convenience inference method taking (N, 5) numpy array and returning (N, latent_dim).
        """
        indices = self.compute_vegetation_indices(multispectral_bands)
        combined = np.hstack([multispectral_bands, indices])

        self.eval()
        with torch.no_grad():
            t_in = torch.from_numpy(combined).float()
            latent, _ = self.forward(t_in)
            return latent.cpu().numpy()
