"""
Spatio-Temporal Agricultural Predictor for Sparse Sensor Fields.
Interpolates and estimates continuous soil and crop variables across unobserved parcels
using Spatial Kriging/IDW and temporal autoregressive state forecasting.
"""

import numpy as np
from typing import Dict, Tuple


class SpatioTemporalPredictor:
    """
    Estimates full 64-zone agricultural state from sparse 24-sensor ground observations.
    Computes spatial interpolation and tracks estimation variance / uncertainty.
    """
    def __init__(self, zone_coords: np.ndarray, num_features: int = 9,
                 power_param: float = 2.0):
        self.zone_coords = zone_coords
        self.num_zones = len(zone_coords)
        self.num_features = num_features
        self.power = power_param

        # Precompute pairwise distance matrix between all zones
        self.dist_matrix = np.zeros((self.num_zones, self.num_zones))
        for i in range(self.num_zones):
            for j in range(self.num_zones):
                self.dist_matrix[i, j] = np.linalg.norm(zone_coords[i] - zone_coords[j])

        # Historical state memory for temporal smoothing
        self.last_estimated_state = None
        self.temporal_momentum = 0.70

    def predict_field_state(self, sparse_readings: Dict[int, np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
        """
        Interpolates spatial field and forecasts unobserved zones.
        sparse_readings: Dict mapping observed_zone_id -> sensor_features (e.g. 24 readings)
        Returns:
            estimated_field: (num_zones, num_features) array
            uncertainty_scores: (num_zones,) array indicating prediction variance
        """
        observed_ids = list(sparse_readings.keys())
        observed_vals = np.array([sparse_readings[zid] for zid in observed_ids])
        num_obs = len(observed_ids)

        estimated_state = np.zeros((self.num_zones, self.num_features))
        uncertainty = np.zeros(self.num_zones)

        for z in range(self.num_zones):
            if z in sparse_readings:
                # Directly observed by ground IoT sensor
                estimated_state[z] = sparse_readings[z]
                uncertainty[z] = 0.05 # Low measurement uncertainty
            else:
                # Unobserved: Spatial Inverse Distance Weighting (IDW) interpolation
                dists = np.array([self.dist_matrix[z, obs_z] for obs_z in observed_ids])
                min_dist = np.min(dists)
                
                # Weights w_i = 1 / d_i^p
                weights = 1.0 / (dists ** self.power + 1e-4)
                weights /= np.sum(weights)

                interpolated = np.sum(weights[:, np.newaxis] * observed_vals, axis=0)
                estimated_state[z] = interpolated

                # Uncertainty proportional to distance from nearest sensor station
                uncertainty[z] = min(1.0, min_dist / 120.0)

        # Apply temporal momentum if previous estimate exists
        if self.last_estimated_state is not None:
            estimated_state = (self.temporal_momentum * self.last_estimated_state +
                               (1.0 - self.temporal_momentum) * estimated_state)

        self.last_estimated_state = estimated_state.copy()
        return estimated_state, uncertainty
