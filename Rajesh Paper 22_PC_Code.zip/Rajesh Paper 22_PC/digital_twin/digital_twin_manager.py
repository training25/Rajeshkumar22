"""
Agricultural Digital Twin Manager.
Maintains the virtual field representation, synchronizes with physical sensors & UAV scans,
tracks synchronization error (DTSE), and generates adaptive scanning priorities.
"""

import numpy as np
from typing import Dict, List, Tuple, Any

from .semantic_vision_encoder import SemanticVisionEncoder
from .spatio_temporal_predictor import SpatioTemporalPredictor


class AgriculturalDigitalTwin:
    """
    Virtual Real-Time Replica of the Physical Farm Field.
    Synchronizes sensor data, visual semantic features, and spatio-temporal predictions.
    """
    def __init__(self, config: dict, zone_coords: np.ndarray):
        self.config = config
        self.zone_coords = zone_coords
        self.num_zones = len(zone_coords)
        self.num_features = 9 # moisture, soil_temp, ph, amb_temp, humidity, N, P, K, EC

        # Submodules
        self.sve = SemanticVisionEncoder(in_bands=5, latent_dim=config['semantic_vision']['latent_dim'])
        self.predictor = SpatioTemporalPredictor(zone_coords, num_features=self.num_features)

        # Virtual Twin State Arrays
        self.virtual_soil_state = np.zeros((self.num_zones, self.num_features))
        self.virtual_semantic_features = np.zeros((self.num_zones, self.sve.latent_dim))
        self.virtual_uncertainty = np.ones(self.num_zones)
        self.last_scanned_time_hours = np.zeros(self.num_zones)
        self.current_time_hours = 0.0

        # Sync tracking
        self.sync_error_history = []
        self.last_sync_error = 0.0

    def update_with_sparse_iot(self, sparse_readings: Dict[int, np.ndarray]):
        """
        Updates the Digital Twin with sparse IoT ground sensor measurements
        and executes spatio-temporal prediction for unobserved zones.
        """
        estimated_state, uncertainty = self.predictor.predict_field_state(sparse_readings)
        self.virtual_soil_state = estimated_state
        self.virtual_uncertainty = uncertainty

    def update_with_uav_scan(self, scanned_zones: List[int], multispectral_data: np.ndarray):
        """
        Updates the Digital Twin with newly acquired UAV multispectral imagery.
        scanned_zones: List of zone IDs visited by UAV
        multispectral_data: (num_scanned, 5) band reflectances
        """
        if len(scanned_zones) == 0:
            return

        # Extract semantic embeddings using SVE
        latent_features = self.sve.extract_features_numpy(multispectral_data)
        
        for idx, z in enumerate(scanned_zones):
            self.virtual_semantic_features[z] = latent_features[idx]
            self.virtual_uncertainty[z] = 0.02 # High confidence after direct aerial observation
            self.last_scanned_time_hours[z] = self.current_time_hours

    def compute_synchronization_error(self, true_physical_state: np.ndarray) -> float:
        """
        Calculates Digital Twin Synchronization Error (DTSE):
        Normalized Euclidean distance between physical ground truth and virtual twin state.
        """
        diff = np.linalg.norm(true_physical_state - self.virtual_soil_state, axis=1)
        norm_true = np.linalg.norm(true_physical_state, axis=1) + 1e-6
        dtse = float(np.mean(diff / norm_true))
        self.last_sync_error = dtse
        self.sync_error_history.append(dtse)
        return dtse

    def compute_prediction_errors(self, true_physical_state: np.ndarray,
                                  unobserved_mask: np.ndarray) -> Tuple[float, float]:
        """
        Calculates Prediction MAE and RMSE exclusively on unobserved parcels.
        """
        if not np.any(unobserved_mask):
            return 0.0, 0.0

        err = np.abs(true_physical_state[unobserved_mask] - self.virtual_soil_state[unobserved_mask])
        mae = float(np.mean(err))
        rmse = float(np.sqrt(np.mean(err ** 2)))
        return mae, rmse

    def compute_uav_scanning_priorities(self) -> np.ndarray:
        """
        Calculates adaptive scanning priority score in [0.0, 1.0] for each field parcel.
        Prioritizes parcels with:
        1. High spatio-temporal prediction uncertainty
        2. Soil moisture dropping near water stress threshold
        3. Stale observation time (elapsed hours since last aerial scan)
        """
        moisture = self.virtual_soil_state[:, 0]
        optimal_moisture = self.config['crop_parameters']['optimal_soil_moisture_pct']
        
        # Stress deficit indicator
        deficit_score = np.clip((optimal_moisture - moisture) / 15.0, 0.0, 1.0)
        
        # Stale time indicator
        time_since_scan = self.current_time_hours - self.last_scanned_time_hours
        staleness_score = np.clip(time_since_scan / 12.0, 0.0, 1.0)

        # Composite priority formula
        priorities = (0.45 * self.virtual_uncertainty +
                      0.35 * deficit_score +
                      0.20 * staleness_score)

        return np.clip(priorities, 0.0, 1.0)
